import pandas as pd
import numpy as np
import os
from sklearn.tree import DecisionTreeRegressor, export_text, export_graphviz
from sklearn.model_selection import train_test_split, KFold, RandomizedSearchCV
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

# 设置全局字体为新罗马
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 12

# 创建保存结果的目录
output_dir = r"E:\课题组\碳纤维\DecisionTree结果"
os.makedirs(output_dir, exist_ok=True)

# 读取数据
df = pd.read_excel('E:\课题组\碳纤维\碳纤维数据集（25行）.xlsx')

# 选择特征和目标变量 - 预测动态抗压强度
feature_columns = ['掺量', '冲击速度']
target_column = '能量'

# 处理数据
data = df[feature_columns + [target_column]].dropna()
X = data[feature_columns].copy()
y = data[target_column].copy()

# 确保所有特征都是数值型
X = X.apply(pd.to_numeric, errors='coerce')
y = pd.to_numeric(y, errors='coerce')

# 处理无效值并对齐长度
X = X.replace([np.inf, -np.inf], np.nan).dropna()
y = y.replace([np.inf, -np.inf], np.nan).dropna()
min_len = min(len(X), len(y))
X, y = X.iloc[:min_len], y.iloc[:min_len]

print(f"数据集大小: {X.shape}")
print(f"特征列: {list(X.columns)}")
print(f"目标列: {target_column}")

# 划分训练集和测试集
X_train_val, X_test, y_train_val, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print("\n训练集大小:", X_train_val.shape)
print("测试集大小:", X_test.shape)

# 决策树不需要对特征进行标准化，但为了保持一致性仍然进行
scaler_X = StandardScaler()
X_train_val_scaled = scaler_X.fit_transform(X_train_val)
X_test_scaled = scaler_X.transform(X_test)

# 决策树不需要对目标变量进行标准化
y_train_val_values = y_train_val.values
y_test_values = y_test.values

# 定义 5 折交叉验证
kf = KFold(n_splits=5, shuffle=True, random_state=42)

print("="*60)
print("决策树回归模型 - 预测动态抗压强度")
print("="*60)

# 计算评估指标的函数
def calculate_metrics(y_true, y_pred):
    mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    
    # 计算MAPE，避免除零
    mask = y_true != 0
    if np.sum(mask) > 0:
        mape = np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100
    else:
        mape = 0
        
    return {'MSE': mse, 'RMSE': rmse, 'MAE': mae, 'R2': r2, 'MAPE': mape}

# 手动进行交叉验证并记录每一折的结果
print("\n开始交叉验证并记录每一折结果...")
fold_results = []
fold_metrics = []

# 用于存储学习曲线数据
learning_curves = {
    'train_rmse': [],
    'val_rmse': [],
    'train_r2': [],
    'val_r2': []
}

for fold, (train_idx, val_idx) in enumerate(kf.split(X_train_val_scaled), 1):
    # 划分训练集和验证集
    X_fold_train, X_fold_val = X_train_val_scaled[train_idx], X_train_val_scaled[val_idx]
    y_fold_train, y_fold_val = y_train_val_values[train_idx], y_train_val_values[val_idx]
    
    # 存储每个fold的学习曲线数据
    fold_train_rmse = []
    fold_val_rmse = []
    fold_train_r2 = []
    fold_val_r2 = []
    
    # 逐步增加树深度并记录性能
    max_depths = range(1, 21)  # 从1到20的最大深度
    for max_depth in max_depths:
        dt_fold = DecisionTreeRegressor(
            max_depth=max_depth,
            random_state=42
        )
        dt_fold.fit(X_fold_train, y_fold_train)
        
        # 训练集预测
        y_fold_train_pred = dt_fold.predict(X_fold_train)
        train_rmse = np.sqrt(mean_squared_error(y_fold_train, y_fold_train_pred))
        train_r2 = r2_score(y_fold_train, y_fold_train_pred)
        
        # 验证集预测
        y_fold_val_pred = dt_fold.predict(X_fold_val)
        val_rmse = np.sqrt(mean_squared_error(y_fold_val, y_fold_val_pred))
        val_r2 = r2_score(y_fold_val, y_fold_val_pred)
        
        fold_train_rmse.append(train_rmse)
        fold_val_rmse.append(val_rmse)
        fold_train_r2.append(train_r2)
        fold_val_r2.append(val_r2)
    
    # 存储当前fold的学习曲线
    learning_curves['train_rmse'].append(fold_train_rmse)
    learning_curves['val_rmse'].append(fold_val_rmse)
    learning_curves['train_r2'].append(fold_train_r2)
    learning_curves['val_r2'].append(fold_val_r2)
    
    # 使用默认参数训练模型（后面会替换为搜索到的最佳参数）
    dt_fold = DecisionTreeRegressor(random_state=42)
    dt_fold.fit(X_fold_train, y_fold_train)
    
    # 预测
    y_fold_pred = dt_fold.predict(X_fold_val)
    
    # 计算指标
    metrics = calculate_metrics(y_fold_val, y_fold_pred)
    
    # 记录结果
    fold_results.append({
        'Fold': fold,
        'MSE': metrics['MSE'],
        'RMSE': metrics['RMSE'],
        'MAE': metrics['MAE'],
        'R2': metrics['R2'],
        'MAPE': metrics['MAPE']
    })
    
    fold_metrics.append(metrics)
    
    print(f"第{fold}折 - MSE: {metrics['MSE']:.4f}, RMSE: {metrics['RMSE']:.4f}, "
          f"MAE: {metrics['MAE']:.4f}, R²: {metrics['R2']:.4f}, MAPE: {metrics['MAPE']:.2f}%")

# 计算平均指标
avg_metrics = {
    'MSE': np.mean([m['MSE'] for m in fold_metrics]),
    'RMSE': np.mean([m['RMSE'] for m in fold_metrics]),
    'MAE': np.mean([m['MAE'] for m in fold_metrics]),
    'R2': np.mean([m['R2'] for m in fold_metrics]),
    'MAPE': np.mean([m['MAPE'] for m in fold_metrics])
}

print(f"\n交叉验证平均结果 - MSE: {avg_metrics['MSE']:.4f}, RMSE: {avg_metrics['RMSE']:.4f}, "
      f"MAE: {avg_metrics['MAE']:.4f}, R²: {avg_metrics['R2']:.4f}, MAPE: {avg_metrics['MAPE']:.2f}%")

# 绘制K折学习曲线
print("\n绘制K折交叉验证学习曲线...")
max_depths_range = range(1, 21)

# 计算平均学习曲线和标准差
avg_train_rmse = np.mean(learning_curves['train_rmse'], axis=0)
avg_val_rmse = np.mean(learning_curves['val_rmse'], axis=0)
avg_train_r2 = np.mean(learning_curves['train_r2'], axis=0)
avg_val_r2 = np.mean(learning_curves['val_r2'], axis=0)

# 计算标准差
std_train_rmse = np.std(learning_curves['train_rmse'], axis=0)
std_val_rmse = np.std(learning_curves['val_rmse'], axis=0)
std_train_r2 = np.std(learning_curves['train_r2'], axis=0)
std_val_r2 = np.std(learning_curves['val_r2'], axis=0)

# 创建学习曲线图
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 5))

# RMSE学习曲线
ax1.plot(max_depths_range, avg_train_rmse, 'b-', label='Training RMSE', linewidth=2)
ax1.fill_between(max_depths_range, 
                avg_train_rmse - std_train_rmse, 
                avg_train_rmse + std_train_rmse, 
                alpha=0.2, color='b')
ax1.plot(max_depths_range, avg_val_rmse, 'r-', label='Validation RMSE', linewidth=2)
ax1.fill_between(max_depths_range, 
                avg_val_rmse - std_val_rmse, 
                avg_val_rmse + std_val_rmse, 
                alpha=0.2, color='r')
ax1.set_xlabel('Maximum Tree Depth')
ax1.set_ylabel('RMSE')
ax1.set_title('Decision Tree RMSE Learning Curve (K-fold Mean ± Std)')
ax1.legend()
ax1.grid(True, alpha=0.3)

# R²学习曲线
ax2.plot(max_depths_range, avg_train_r2, 'b-', label='Training R²', linewidth=2)
ax2.fill_between(max_depths_range, 
                avg_train_r2 - std_train_r2, 
                avg_train_r2 + std_train_r2, 
                alpha=0.2, color='b')
ax2.plot(max_depths_range, avg_val_r2, 'r-', label='Validation R²', linewidth=2)
ax2.fill_between(max_depths_range, 
                avg_val_r2 - std_val_r2, 
                avg_val_r2 + std_val_r2, 
                alpha=0.2, color='r')
ax2.set_xlabel('Maximum Tree Depth')
ax2.set_ylabel('R² Score')
ax2.set_title('Decision Tree R² Learning Curve (K-fold Mean ± Std)')
ax2.legend()
ax2.grid(True, alpha=0.3)

plt.tight_layout()
learning_curve_path = os.path.join(output_dir, 'DecisionTree_K-fold_Learning_Curves.png')
plt.savefig(learning_curve_path, dpi=300, bbox_inches='tight')
plt.show()

print(f"K折学习曲线已保存至: {learning_curve_path}")

# 保存学习曲线数据（包含标准差）
learning_curve_df = pd.DataFrame({
    'max_depth': max_depths_range,
    'avg_train_rmse': avg_train_rmse,
    'std_train_rmse': std_train_rmse,
    'avg_val_rmse': avg_val_rmse,
    'std_val_rmse': std_val_rmse,
    'avg_train_r2': avg_train_r2,
    'std_train_r2': std_train_r2,
    'avg_val_r2': avg_val_r2,
    'std_val_r2': std_val_r2
})
learning_curve_df.to_excel(os.path.join(output_dir, 'DecisionTree_Learning_Curve_Data.xlsx'), index=False)

# 找出最佳树深度（验证集RMSE最小）
best_max_depth_rmse = max_depths_range[np.argmin(avg_val_rmse)]
best_rmse = np.min(avg_val_rmse)
print(f"\n基于验证集RMSE的最佳树深度: {best_max_depth_rmse} (RMSE: {best_rmse:.4f})")

# 找出最佳树深度（验证集R²最大）
best_max_depth_r2 = max_depths_range[np.argmax(avg_val_r2)]
best_r2 = np.max(avg_val_r2)
print(f"基于验证集R²的最佳树深度: {best_max_depth_r2} (R²: {best_r2:.4f})")

# 决策树的超参数搜索空间
param_dist = {
    'criterion': ['squared_error'],
    'max_depth': [2, 3],
    'min_samples_split': [10, 15],
    'min_samples_leaf': [7, 10],
    'max_leaf_nodes': [5, 8],
    'ccp_alpha': [0.3, 0.5, 1.0]
}

dt = DecisionTreeRegressor(random_state=42)
random_search = RandomizedSearchCV(
    estimator=dt,
    param_distributions=param_dist,
    n_iter=50,  # 搜索迭代次数
    cv=kf,
    scoring='r2',
    random_state=42,
    n_jobs=-1
)

print("\n开始超参数搜索...")
random_search.fit(X_train_val_scaled, y_train_val_values)
best_model = random_search.best_estimator_
best_params = random_search.best_params_
print("最佳超参数:", best_params)

# 预测
y_pred_train = best_model.predict(X_train_val_scaled)
y_pred_test = best_model.predict(X_test_scaled)

train_metrics = calculate_metrics(y_train_val_values, y_pred_train)
test_metrics = calculate_metrics(y_test_values, y_pred_test)

# 输出结果
print("\n训练集评估结果：")
print(f"MSE: {train_metrics['MSE']:.4f}, RMSE: {train_metrics['RMSE']:.4f}, "
      f"MAE: {train_metrics['MAE']:.4f}, R²: {train_metrics['R2']:.4f}, MAPE: {train_metrics['MAPE']:.2f}%")

print("\n测试集评估结果：")
print(f"MSE: {test_metrics['MSE']:.4f}, RMSE: {test_metrics['RMSE']:.4f}, "
      f"MAE: {test_metrics['MAE']:.4f}, R²: {test_metrics['R2']:.4f}, MAPE: {test_metrics['MAPE']:.2f}%")

# 保存预测结果
predictions = pd.DataFrame({
    '样本类型': ['训练集'] * len(y_train_val_values) + ['测试集'] * len(y_test_values),
    '真实值': np.concatenate([y_train_val_values, y_test_values]),
    '预测值': np.concatenate([y_pred_train, y_pred_test]),
    '误差': np.concatenate([y_pred_train - y_train_val_values, y_pred_test - y_test_values])
})

# 保存到Excel
output_path = os.path.join(output_dir, 'DecisionTree_能量.xlsx')
with pd.ExcelWriter(output_path) as writer:
    # 评估指标
    metrics_df = pd.DataFrame({
        '评估指标': ['MSE', 'RMSE', 'MAE', 'R²', 'MAPE(%)'],
        '训练集': [train_metrics['MSE'], train_metrics['RMSE'], train_metrics['MAE'], 
                 train_metrics['R2'], train_metrics['MAPE']],
        '测试集': [test_metrics['MSE'], test_metrics['RMSE'], test_metrics['MAE'], 
                 test_metrics['R2'], test_metrics['MAPE']]
    })
    metrics_df.to_excel(writer, sheet_name='评估指标', index=False)
    
    # 预测详情
    predictions.to_excel(writer, sheet_name='预测详情', index=False)
    
    # 最佳参数
    params_df = pd.DataFrame(list(best_params.items()), columns=['参数', '值'])
    params_df.to_excel(writer, sheet_name='最佳参数', index=False)
    
    # 每一折的交叉验证结果
    fold_results_df = pd.DataFrame(fold_results)
    fold_results_df.to_excel(writer, sheet_name='交叉验证结果', index=False)
    
    # 学习曲线数据
    learning_curve_df.to_excel(writer, sheet_name='学习曲线数据', index=False)

print(f"\n结果已保存至: {output_path}")

# 性能总结
overfit_degree = train_metrics['R2'] - test_metrics['R2']
print("\n" + "="*60)
print("模型性能总结")
print("="*60)
print(f"训练集R²: {train_metrics['R2']:.4f}")
print(f"测试集R²: {test_metrics['R2']:.4f}")
print(f"训练集MAPE: {train_metrics['MAPE']:.2f}%")
print(f"测试集MAPE: {test_metrics['MAPE']:.2f}%")
print(f"过拟合程度: {overfit_degree:.4f}")

if overfit_degree > 0.2:
    print("⚠️  警告：模型存在明显过拟合！")
elif overfit_degree > 0.1:
    print("⚠️  注意：模型存在轻微过拟合")
else:
    print("✅ 模型泛化能力良好")

# 添加额外的模型评估
print("\n" + "="*60)
print("额外评估指标")
print("="*60)

# 计算额外指标
from scipy.stats import pearsonr

# 相关系数
train_corr, _ = pearsonr(y_train_val_values, y_pred_train)
test_corr, _ = pearsonr(y_test_values, y_pred_test)

print(f"训练集相关系数: {train_corr:.4f}")
print(f"测试集相关系数: {test_corr:.4f}")

# 计算预测偏差
train_bias = np.mean(y_pred_train - y_train_val_values)
test_bias = np.mean(y_pred_test - y_test_values)

print(f"训练集平均偏差: {train_bias:.4f}")
print(f"测试集平均偏差: {test_bias:.4f}")

# 特征重要性
print("\n" + "="*60)
print("特征重要性")
print("="*60)
feature_importance = best_model.feature_importances_
for feature, importance in zip(feature_columns, feature_importance):
    print(f"{feature}: {importance:.4f}")

# 保存特征重要性
importance_df = pd.DataFrame({
    '特征': feature_columns,
    '重要性': feature_importance
}).sort_values('重要性', ascending=False)
importance_df.to_excel(os.path.join(output_dir, 'DecisionTree_特征重要性.xlsx'), index=False)

# 决策树结构分析
print("\n" + "="*60)
print("决策树结构分析")
print("="*60)
print(f"树深度: {best_model.get_depth()}")
print(f"叶子节点数量: {best_model.get_n_leaves()}")
print(f"特征数量: {best_model.n_features_in_}")

# 保存树结构分析
tree_structure_df = pd.DataFrame({
    '指标': ['树深度', '叶子节点数量', '特征数量'],
    '值': [best_model.get_depth(), best_model.get_n_leaves(), best_model.n_features_in_]
})
tree_structure_df.to_excel(os.path.join(output_dir, 'DecisionTree_结构分析.xlsx'), index=False)

# 决策规则提取
print("\n" + "="*60)
print("决策规则（前10条路径）")
print("="*60)

# 使用export_text获取决策规则
tree_rules = export_text(best_model, feature_names=feature_columns, max_depth=10)
print(tree_rules)

# 保存决策规则
with open(os.path.join(output_dir, 'DecisionTree_决策规则.txt'), 'w', encoding='utf-8') as f:
    f.write("Decision Tree Rules:\n")
    f.write("="*50 + "\n")
    f.write(tree_rules)

# 决策路径分析
print("\n" + "="*60)
print("决策路径分析")
print("="*60)

# 获取测试集样本的决策路径
decision_paths = best_model.decision_path(X_test_scaled)
print(f"决策路径形状: {decision_paths.shape}")

# 计算平均路径长度
avg_path_length = np.mean(decision_paths.sum(axis=1))
print(f"平均决策路径长度: {avg_path_length:.2f}")

# 保存决策路径分析
path_analysis_df = pd.DataFrame({
    '指标': ['决策路径形状', '平均决策路径长度'],
    '值': [str(decision_paths.shape), f"{avg_path_length:.2f}"]
})
path_analysis_df.to_excel(os.path.join(output_dir, 'DecisionTree_决策路径分析.xlsx'), index=False)

# 叶子节点统计
print("\n" + "="*60)
print("叶子节点统计")
print("="*60)

# 获取每个叶子节点的样本数量
leaf_ids = best_model.apply(X_train_val_scaled)
unique_leaf_ids, leaf_counts = np.unique(leaf_ids, return_counts=True)

print(f"叶子节点ID范围: {min(unique_leaf_ids)} - {max(unique_leaf_ids)}")
print(f"最小叶子节点样本数: {min(leaf_counts)}")
print(f"最大叶子节点样本数: {max(leaf_counts)}")
print(f"平均叶子节点样本数: {np.mean(leaf_counts):.2f}")

# 保存叶子节点统计
leaf_stats_df = pd.DataFrame({
    '叶子节点ID': unique_leaf_ids,
    '样本数量': leaf_counts
})
leaf_stats_df.to_excel(os.path.join(output_dir, 'DecisionTree_叶子节点统计.xlsx'), index=False)

# 模型复杂度分析
print("\n" + "="*60)
print("模型复杂度分析")
print("="*60)
print(f"分裂准则: {best_params.get('criterion', '未指定')}")
print(f"最大深度: {best_params.get('max_depth', '未指定')}")
print(f"最小分裂样本数: {best_params.get('min_samples_split', '未指定')}")
print(f"最小叶子节点样本数: {best_params.get('min_samples_leaf', '未指定')}")

# 保存复杂度分析
complexity_df = pd.DataFrame({
    '参数': ['分裂准则', '最大深度', '最小分裂样本数', '最小叶子节点样本数'],
    '值': [
        best_params.get('criterion', '未指定'),
        best_params.get('max_depth', '未指定'),
        best_params.get('min_samples_split', '未指定'),
        best_params.get('min_samples_leaf', '未指定')
    ]
})
complexity_df.to_excel(os.path.join(output_dir, 'DecisionTree_复杂度分析.xlsx'), index=False)

# 可视化决策树（如果需要，可以安装graphviz）
try:
    # 导出为DOT格式
    dot_data = export_graphviz(
        best_model,
        out_file=None,
        feature_names=feature_columns,
        filled=True,
        rounded=True,
        special_characters=True,
        max_depth=3  # 限制深度以便可视化
    )
    
    # 保存DOT文件
    with open(os.path.join(output_dir, 'DecisionTree_可视化.dot'), 'w') as f:
        f.write(dot_data)
    print("\n决策树DOT文件已保存，可使用graphviz转换为图像")
except Exception as e:
    print(f"\n决策树可视化保存失败: {e}")
    print("请安装graphviz: pip install graphviz")