import pandas as pd
import numpy as np
import os
from sklearn.neighbors import KNeighborsRegressor
from sklearn.model_selection import train_test_split, KFold, RandomizedSearchCV, GridSearchCV
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.preprocessing import StandardScaler, RobustScaler, MinMaxScaler
from sklearn.feature_selection import SelectKBest, f_regression, mutual_info_regression
from sklearn.decomposition import PCA
from sklearn.ensemble import BaggingRegressor
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

# 设置全局字体为新罗马
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 12

# 创建保存结果的目录
output_dir = r"E:\课题组\碳纤维\KNN结果"
os.makedirs(output_dir, exist_ok=True)

# 读取数据
df = pd.read_excel('E:\课题组\碳纤维\碳纤维数据集（25行）.xlsx')

# 选择特征和目标变量 - 预测动态抗压强度
feature_columns = ['掺量', '冲击速度']
target_column = '动态抗压强度'

# 处理数据
data = df[feature_columns + [target_column]].dropna()
X = data[feature_columns].copy()
y = data[target_column].copy()

# 确保所有特征都是数值型
X = X.apply(pd.to_numeric, errors='coerce')
y = pd.to_numeric(y, errors='coerce')

# 处理无效值并对齐长度
X = X.replace([np.inf, -np.inf], np.nan).dropna()
y = y.replace([np.inf, -np.inf], np.nan).dropna()
min_len = min(len(X), len(y))
X, y = X.iloc[:min_len], y.iloc[:min_len]

print(f"数据集大小: {X.shape}")
print(f"特征列: {list(X.columns)}")
print(f"目标列: {target_column}")

# 数据探索分析
print("\n" + "="*60)
print("数据探索分析")
print("="*60)
print(f"目标变量统计:")
print(f"  均值: {y.mean():.4f}")
print(f"  标准差: {y.std():.4f}")
print(f"  最小值: {y.min():.4f}")
print(f"  最大值: {y.max():.4f}")
print(f"  变异系数: {y.std()/y.mean()*100:.2f}%")

for feature in feature_columns:
    print(f"\n{feature}统计:")
    print(f"  均值: {X[feature].mean():.4f}")
    print(f"  标准差: {X[feature].std():.4f}")
    print(f"  与目标变量的相关系数: {X[feature].corr(y):.4f}")

# 划分训练集和测试集
X_train_val, X_test, y_train_val, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=None
)

print("\n训练集大小:", X_train_val.shape)
print("测试集大小:", X_test.shape)

# 多种标准化方法比较
print("\n" + "="*60)
print("数据标准化方法比较")
print("="*60)

scalers = {
    'StandardScaler': StandardScaler(),
    'RobustScaler': RobustScaler(),
    'MinMaxScaler': MinMaxScaler()
}

best_scaler = None
best_scaler_name = ''
best_score = -np.inf

# 计算评估指标的函数
def calculate_metrics(y_true, y_pred):
    mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    
    # 计算MAPE，避免除零
    mask = y_true != 0
    if np.sum(mask) > 0:
        mape = np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100
    else:
        mape = 0
        
    # 计算解释方差分数
    explained_variance = 1 - np.var(y_true - y_pred) / np.var(y_true)
    
    return {
        'MSE': mse, 
        'RMSE': rmse, 
        'MAE': mae, 
        'R2': r2, 
        'MAPE': mape,
        'Explained_Variance': explained_variance
    }

for scaler_name, scaler in scalers.items():
    # 标准化
    X_train_val_scaled = scaler.fit_transform(X_train_val)
    X_test_scaled = scaler.transform(X_test)
    
    # 使用简单的KNN进行初步评估
    knn_temp = KNeighborsRegressor(n_neighbors=5)
    scores = []
    fold_results_temp = []
    
    for fold, (train_idx, val_idx) in enumerate(KFold(n_splits=5, shuffle=True, random_state=42).split(X_train_val_scaled), 1):
        X_train_fold, X_val_fold = X_train_val_scaled[train_idx], X_train_val_scaled[val_idx]
        y_train_fold, y_val_fold = y_train_val.values[train_idx], y_train_val.values[val_idx]
        
        knn_temp.fit(X_train_fold, y_train_fold)
        y_pred = knn_temp.predict(X_val_fold)
        score = r2_score(y_val_fold, y_pred)
        scores.append(score)
        
        # 计算详细指标
        metrics = calculate_metrics(y_val_fold, y_pred)
        fold_results_temp.append({
            'Fold': fold,
            'MSE': metrics['MSE'],
            'RMSE': metrics['RMSE'],
            'MAE': metrics['MAE'],
            'R2': metrics['R2'],
            'MAPE': metrics['MAPE']
        })
    
    mean_score = np.mean(scores)
    print(f"{scaler_name}: 平均R² = {mean_score:.4f}")
    
    if mean_score > best_score:
        best_score = mean_score
        best_scaler = scaler
        best_scaler_name = scaler_name

print(f"\n选择最佳标准化方法: {best_scaler_name}")

# 使用最佳标准化方法
X_train_val_scaled = best_scaler.fit_transform(X_train_val)
X_test_scaled = best_scaler.transform(X_test)

y_train_val_values = y_train_val.values
y_test_values = y_test.values

# 定义 5 折交叉验证
kf = KFold(n_splits=5, shuffle=True, random_state=42)

print("\n" + "="*60)
print("优化后的K近邻回归模型 - 预测动态抗压强度")
print("="*60)

# 手动进行交叉验证并记录每一折的结果
print("\n开始交叉验证并记录每一折结果...")
fold_results = []
fold_metrics = []

# 用于存储学习曲线数据
learning_curves = {
    'train_rmse': [],
    'val_rmse': [],
    'train_r2': [],
    'val_r2': []
}

# KNN学习曲线 - 分析不同K值对性能的影响
print("\n开始KNN学习曲线分析...")
k_values_range = range(1, min(21, len(X_train_val_scaled)//2))

for fold, (train_idx, val_idx) in enumerate(kf.split(X_train_val_scaled), 1):
    # 划分训练集和验证集
    X_fold_train, X_fold_val = X_train_val_scaled[train_idx], X_train_val_scaled[val_idx]
    y_fold_train, y_fold_val = y_train_val_values[train_idx], y_train_val_values[val_idx]
    
    # 存储每个fold的学习曲线数据
    fold_train_rmse = []
    fold_val_rmse = []
    fold_train_r2 = []
    fold_val_r2 = []
    
    # 分析不同K值对性能的影响
    for k_value in k_values_range:
        knn_fold = KNeighborsRegressor(n_neighbors=k_value)
        knn_fold.fit(X_fold_train, y_fold_train)
        
        # 训练集预测
        y_fold_train_pred = knn_fold.predict(X_fold_train)
        train_rmse = np.sqrt(mean_squared_error(y_fold_train, y_fold_train_pred))
        train_r2 = r2_score(y_fold_train, y_fold_train_pred)
        
        # 验证集预测
        y_fold_val_pred = knn_fold.predict(X_fold_val)
        val_rmse = np.sqrt(mean_squared_error(y_fold_val, y_fold_val_pred))
        val_r2 = r2_score(y_fold_val, y_fold_val_pred)
        
        fold_train_rmse.append(train_rmse)
        fold_val_rmse.append(val_rmse)
        fold_train_r2.append(train_r2)
        fold_val_r2.append(val_r2)
    
    # 存储当前fold的学习曲线
    learning_curves['train_rmse'].append(fold_train_rmse)
    learning_curves['val_rmse'].append(fold_val_rmse)
    learning_curves['train_r2'].append(fold_train_r2)
    learning_curves['val_r2'].append(fold_val_r2)
    
    # 使用默认参数训练模型（后面会替换为搜索到的最佳参数）
    knn_fold = KNeighborsRegressor(n_neighbors=5)
    knn_fold.fit(X_fold_train, y_fold_train)
    
    # 预测
    y_fold_pred = knn_fold.predict(X_fold_val)
    
    # 计算指标
    metrics = calculate_metrics(y_fold_val, y_fold_pred)
    
    # 记录结果
    fold_results.append({
        'Fold': fold,
        'MSE': metrics['MSE'],
        'RMSE': metrics['RMSE'],
        'MAE': metrics['MAE'],
        'R2': metrics['R2'],
        'MAPE': metrics['MAPE']
    })
    
    fold_metrics.append(metrics)
    
    print(f"第{fold}折 - MSE: {metrics['MSE']:.4f}, RMSE: {metrics['RMSE']:.4f}, "
          f"MAE: {metrics['MAE']:.4f}, R²: {metrics['R2']:.4f}, MAPE: {metrics['MAPE']:.2f}%")

# 计算平均指标
avg_metrics = {
    'MSE': np.mean([m['MSE'] for m in fold_metrics]),
    'RMSE': np.mean([m['RMSE'] for m in fold_metrics]),
    'MAE': np.mean([m['MAE'] for m in fold_metrics]),
    'R2': np.mean([m['R2'] for m in fold_metrics]),
    'MAPE': np.mean([m['MAPE'] for m in fold_metrics])
}

print(f"\n交叉验证平均结果 - MSE: {avg_metrics['MSE']:.4f}, RMSE: {avg_metrics['RMSE']:.4f}, "
      f"MAE: {avg_metrics['MAE']:.4f}, R²: {avg_metrics['R2']:.4f}, MAPE: {avg_metrics['MAPE']:.2f}%")

# 绘制K折学习曲线
print("\n绘制KNN K-fold学习曲线...")

# 计算平均学习曲线和标准差
avg_train_rmse = np.mean(learning_curves['train_rmse'], axis=0)
avg_val_rmse = np.mean(learning_curves['val_rmse'], axis=0)
avg_train_r2 = np.mean(learning_curves['train_r2'], axis=0)
avg_val_r2 = np.mean(learning_curves['val_r2'], axis=0)

# 计算标准差
std_train_rmse = np.std(learning_curves['train_rmse'], axis=0)
std_val_rmse = np.std(learning_curves['val_rmse'], axis=0)
std_train_r2 = np.std(learning_curves['train_r2'], axis=0)
std_val_r2 = np.std(learning_curves['val_r2'], axis=0)

# 创建学习曲线图
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 5))

# RMSE学习曲线
ax1.plot(k_values_range, avg_train_rmse, 'b-', label='Training RMSE', linewidth=2)
ax1.fill_between(k_values_range, 
                avg_train_rmse - std_train_rmse, 
                avg_train_rmse + std_train_rmse, 
                alpha=0.2, color='b')
ax1.plot(k_values_range, avg_val_rmse, 'r-', label='Validation RMSE', linewidth=2)
ax1.fill_between(k_values_range, 
                avg_val_rmse - std_val_rmse, 
                avg_val_rmse + std_val_rmse, 
                alpha=0.2, color='r')
ax1.set_xlabel('Number of Neighbors (K)')
ax1.set_ylabel('RMSE')
ax1.set_title('KNN RMSE Learning Curve (K-fold Mean ± Std)')
ax1.legend()
ax1.grid(True, alpha=0.3)

# R²学习曲线
ax2.plot(k_values_range, avg_train_r2, 'b-', label='Training R²', linewidth=2)
ax2.fill_between(k_values_range, 
                avg_train_r2 - std_train_r2, 
                avg_train_r2 + std_train_r2, 
                alpha=0.2, color='b')
ax2.plot(k_values_range, avg_val_r2, 'r-', label='Validation R²', linewidth=2)
ax2.fill_between(k_values_range, 
                avg_val_r2 - std_val_r2, 
                avg_val_r2 + std_val_r2, 
                alpha=0.2, color='r')
ax2.set_xlabel('Number of Neighbors (K)')
ax2.set_ylabel('R² Score')
ax2.set_title('KNN R² Learning Curve (K-fold Mean ± Std)')
ax2.legend()
ax2.grid(True, alpha=0.3)

plt.tight_layout()
learning_curve_path = os.path.join(output_dir, 'KNN_K-fold_Learning_Curves.png')
plt.savefig(learning_curve_path, dpi=300, bbox_inches='tight')
plt.show()

print(f"KNN K-fold学习曲线已保存至: {learning_curve_path}")

# 保存学习曲线数据（包含标准差）
learning_curve_df = pd.DataFrame({
    'n_neighbors': list(k_values_range),
    'avg_train_rmse': avg_train_rmse,
    'std_train_rmse': std_train_rmse,
    'avg_val_rmse': avg_val_rmse,
    'std_val_rmse': std_val_rmse,
    'avg_train_r2': avg_train_r2,
    'std_train_r2': std_train_r2,
    'avg_val_r2': avg_val_r2,
    'std_val_r2': std_val_r2
})
learning_curve_df.to_excel(os.path.join(output_dir, 'KNN_Learning_Curve_Data.xlsx'), index=False)

# 找出最佳K值（验证集RMSE最小）
best_k_rmse = list(k_values_range)[np.argmin(avg_val_rmse)]
best_rmse = np.min(avg_val_rmse)
print(f"\n基于验证集RMSE的最佳K值: {best_k_rmse} (RMSE: {best_rmse:.4f})")

# 找出最佳K值（验证集R²最大）
best_k_r2 = list(k_values_range)[np.argmax(avg_val_r2)]
best_r2 = np.max(avg_val_r2)
print(f"基于验证集R²的最佳K值: {best_k_r2} (R²: {best_r2:.4f})")

# 扩展的KNN超参数搜索空间
param_dist = {
    'n_neighbors': list(range(1, min(21, len(X_train_val_scaled)//2))),
    'weights': ['uniform', 'distance'],
    'algorithm': ['auto', 'ball_tree', 'kd_tree', 'brute'],
    'leaf_size': [10, 15, 20, 25, 30, 35, 40, 50],
    'p': [1, 2, 3],  # 1:曼哈顿距离, 2:欧氏距离, 3:闵可夫斯基距离
    'metric': ['minkowski', 'euclidean', 'manhattan', 'chebyshev']
}

# 使用集成方法包装KNN
base_knn = KNeighborsRegressor()
knn_model = BaggingRegressor(
    base_estimator=base_knn,
    n_estimators=10,
    max_samples=0.8,
    max_features=1.0,
    bootstrap=True,
    bootstrap_features=False,
    random_state=42,
    n_jobs=-1
)

# 为Bagging调整参数搜索空间
bagging_param_dist = {
    'base_estimator__n_neighbors': param_dist['n_neighbors'],
    'base_estimator__weights': param_dist['weights'],
    'base_estimator__algorithm': param_dist['algorithm'],
    'base_estimator__leaf_size': param_dist['leaf_size'],
    'base_estimator__p': param_dist['p'],
    'base_estimator__metric': param_dist['metric'],
    'n_estimators': [5, 10, 15, 20],
    'max_samples': [0.6, 0.7, 0.8, 0.9, 1.0],
    'bootstrap': [True, False]
}

print("\n开始超参数搜索...")
random_search = RandomizedSearchCV(
    estimator=knn_model,
    param_distributions=bagging_param_dist,
    n_iter=100,  # 增加搜索迭代次数
    cv=kf,
    scoring='r2',
    random_state=42,
    n_jobs=-1
)

random_search.fit(X_train_val_scaled, y_train_val_values)
best_model = random_search.best_estimator_
best_params = random_search.best_params_
print("最佳超参数:", best_params)

# 预测
y_pred_train = best_model.predict(X_train_val_scaled)
y_pred_test = best_model.predict(X_test_scaled)

train_metrics = calculate_metrics(y_train_val_values, y_pred_train)
test_metrics = calculate_metrics(y_test_values, y_pred_test)

# 输出结果
print("\n训练集评估结果：")
print(f"MSE: {train_metrics['MSE']:.4f}, RMSE: {train_metrics['RMSE']:.4f}, "
      f"MAE: {train_metrics['MAE']:.4f}, R²: {train_metrics['R2']:.4f}, "
      f"MAPE: {train_metrics['MAPE']:.2f}%, 解释方差: {train_metrics['Explained_Variance']:.4f}")

print("\n测试集评估结果：")
print(f"MSE: {test_metrics['MSE']:.4f}, RMSE: {test_metrics['RMSE']:.4f}, "
      f"MAE: {test_metrics['MAE']:.4f}, R²: {test_metrics['R2']:.4f}, "
      f"MAPE: {test_metrics['MAPE']:.2f}%, 解释方差: {test_metrics['Explained_Variance']:.4f}")

# 保存预测结果
predictions = pd.DataFrame({
    '样本类型': ['训练集'] * len(y_train_val_values) + ['测试集'] * len(y_test_values),
    '真实值': np.concatenate([y_train_val_values, y_test_values]),
    '预测值': np.concatenate([y_pred_train, y_pred_test]),
    '误差': np.concatenate([y_pred_train - y_train_val_values, y_pred_test - y_test_values]),
    '相对误差(%)': np.concatenate([
        ((y_pred_train - y_train_val_values) / y_train_val_values * 100),
        ((y_pred_test - y_test_values) / y_test_values * 100)
    ])
})

# 保存到Excel
output_path = os.path.join(output_dir, 'KNN优化_动态抗压强度预测结果.xlsx')
with pd.ExcelWriter(output_path) as writer:
    # 评估指标
    metrics_df = pd.DataFrame({
        '评估指标': ['MSE', 'RMSE', 'MAE', 'R²', 'MAPE(%)', '解释方差'],
        '训练集': [
            train_metrics['MSE'], train_metrics['RMSE'], train_metrics['MAE'], 
            train_metrics['R2'], train_metrics['MAPE'], train_metrics['Explained_Variance']
        ],
        '测试集': [
            test_metrics['MSE'], test_metrics['RMSE'], test_metrics['MAE'], 
            test_metrics['R2'], test_metrics['MAPE'], test_metrics['Explained_Variance']
        ]
    })
    metrics_df.to_excel(writer, sheet_name='评估指标', index=False)
    
    # 预测详情
    predictions.to_excel(writer, sheet_name='预测详情', index=False)
    
    # 最佳参数
    params_df = pd.DataFrame(list(best_params.items()), columns=['参数', '值'])
    params_df.to_excel(writer, sheet_name='最佳参数', index=False)
    
    # 标准化信息
    scaler_df = pd.DataFrame({
        '标准化方法': [best_scaler_name]
    })
    scaler_df.to_excel(writer, sheet_name='标准化信息', index=False)
    
    # 每一折的交叉验证结果
    fold_results_df = pd.DataFrame(fold_results)
    fold_results_df.to_excel(writer, sheet_name='交叉验证结果', index=False)
    
    # 学习曲线数据
    learning_curve_df.to_excel(writer, sheet_name='学习曲线数据', index=False)

print(f"\n结果已保存至: {output_path}")

# 性能总结
overfit_degree = train_metrics['R2'] - test_metrics['R2']
print("\n" + "="*60)
print("模型性能总结")
print("="*60)
print(f"训练集R²: {train_metrics['R2']:.4f}")
print(f"测试集R²: {test_metrics['R2']:.4f}")
print(f"训练集MAPE: {train_metrics['MAPE']:.2f}%")
print(f"测试集MAPE: {test_metrics['MAPE']:.2f}%")
print(f"过拟合程度: {overfit_degree:.4f}")

if overfit_degree > 0.2:
    print("⚠️  警告：模型存在明显过拟合！")
    print("建议: 增加正则化，减少模型复杂度，或增加训练数据")
elif overfit_degree > 0.1:
    print("⚠️  注意：模型存在轻微过拟合")
else:
    print("✅ 模型泛化能力良好")

# 模型诊断
print("\n" + "="*60)
print("模型诊断")
print("="*60)

# 计算额外指标
from scipy.stats import pearsonr

# 相关系数
train_corr, _ = pearsonr(y_train_val_values, y_pred_train)
test_corr, _ = pearsonr(y_test_values, y_pred_test)

print(f"训练集相关系数: {train_corr:.4f}")
print(f"测试集相关系数: {test_corr:.4f}")

# 计算预测偏差
train_bias = np.mean(y_pred_train - y_train_val_values)
test_bias = np.mean(y_pred_test - y_test_values)

print(f"训练集平均偏差: {train_bias:.4f}")
print(f"测试集平均偏差: {test_bias:.4f}")

# 残差分析
train_residuals = y_train_val_values - y_pred_train
test_residuals = y_test_values - y_pred_test

print(f"训练集残差标准差: {np.std(train_residuals):.4f}")
print(f"测试集残差标准差: {np.std(test_residuals):.4f}")

# 模型改进建议
print("\n" + "="*60)
print("模型改进建议")
print("="*60)

if test_metrics['R2'] < 0.7:
    print("❌ 模型预测性能较差，建议:")
    print("  1. 检查数据质量，处理异常值")
    print("  2. 考虑增加更多相关特征")
    print("  3. 尝试其他模型算法")
    print("  4. 增加数据量")
elif test_metrics['R2'] < 0.85:
    print("⚠️  模型预测性能一般，建议:")
    print("  1. 进一步优化超参数")
    print("  2. 尝试特征工程")
    print("  3. 考虑使用集成方法")
else:
    print("✅ 模型预测性能良好")

# 特征重要性分析（对于KNN，我们可以使用排列重要性）
print("\n" + "="*60)
print("特征重要性分析")
print("="*60)

# 使用简单的排列重要性
def permutation_importance(model, X, y, metric=r2_score, n_repeats=10):
    baseline_score = metric(y, model.predict(X))
    importances = []
    
    for col in range(X.shape[1]):
        scores = []
        X_permuted = X.copy()
        for _ in range(n_repeats):
            X_permuted[:, col] = np.random.permutation(X_permuted[:, col])
            score = metric(y, model.predict(X_permuted))
            scores.append(score)
        importance = baseline_score - np.mean(scores)
        importances.append(importance)
    
    return np.array(importances)

# 计算特征重要性
feature_importance = permutation_importance(best_model, X_test_scaled, y_test_values)

for feature, importance in zip(feature_columns, feature_importance):
    print(f"{feature}: {importance:.4f}")

# 保存特征重要性
importance_df = pd.DataFrame({
    '特征': feature_columns,
    '重要性': feature_importance
}).sort_values('重要性', ascending=False)
importance_df.to_excel(os.path.join(output_dir, 'KNN优化_特征重要性.xlsx'), index=False)

# 不同K值性能曲线
print("\n" + "="*60)
print("K值选择分析")
print("="*60)

k_values = list(range(1, min(21, len(X_train_val_scaled)//2)))
k_performance = []

for k in k_values:
    knn_temp = KNeighborsRegressor(n_neighbors=k)
    scores = []
    for train_idx, val_idx in kf.split(X_train_val_scaled):
        X_train_fold, X_val_fold = X_train_val_scaled[train_idx], X_train_val_scaled[val_idx]
        y_train_fold, y_val_fold = y_train_val_values[train_idx], y_train_val_values[val_idx]
        
        knn_temp.fit(X_train_fold, y_train_fold)
        y_pred = knn_temp.predict(X_val_fold)
        score = r2_score(y_val_fold, y_pred)
        scores.append(score)
    
    mean_score = np.mean(scores)
    k_performance.append({'K值': k, 'R²': mean_score})
    print(f"K={k}: R² = {mean_score:.4f}")

# 保存K值分析
k_performance_df = pd.DataFrame(k_performance)
k_performance_df.to_excel(os.path.join(output_dir, 'KNN优化_K值分析.xlsx'), index=False)

# 找到最佳K值
best_k_performance = max(k_performance, key=lambda x: x['R²'])
print(f"\n在交叉验证中，K={best_k_performance['K值']}时性能最佳，R² = {best_k_performance['R²']:.4f}")

# 最终模型评估
print("\n" + "="*60)
print("最终模型评估")
print("="*60)

# 使用最佳K值的简单KNN模型进行比较
simple_knn = KNeighborsRegressor(n_neighbors=best_k_performance['K值'])
simple_knn.fit(X_train_val_scaled, y_train_val_values)
y_pred_simple = simple_knn.predict(X_test_scaled)
simple_r2 = r2_score(y_test_values, y_pred_simple)

print(f"简单KNN模型测试集R²: {simple_r2:.4f}")
print(f"优化后KNN模型测试集R²: {test_metrics['R2']:.4f}")
improvement = test_metrics['R2'] - simple_r2
print(f"优化提升: {improvement:.4f}")

if improvement > 0:
    print("✅ 优化措施有效")
else:
    print("⚠️  优化措施效果有限，建议尝试其他方法")

# 保存最终评估
final_evaluation_df = pd.DataFrame({
    '模型类型': ['简单KNN', '优化KNN'],
    '测试集R²': [simple_r2, test_metrics['R2']],
    '提升': [0, improvement]
})
final_evaluation_df.to_excel(os.path.join(output_dir, 'KNN_最终评估.xlsx'), index=False)