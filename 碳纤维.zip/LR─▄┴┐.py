import pandas as pd
import numpy as np
import os
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split, KFold
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

# 设置全局字体为新罗马
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 12

# 创建保存结果的目录
output_dir = r"E:\课题组\碳纤维\LR结果"
os.makedirs(output_dir, exist_ok=True)

# 读取数据
df = pd.read_excel('E:\课题组\碳纤维\碳纤维数据集（25行）.xlsx')

# 选择特征和目标变量 - 预测动态抗压强度
feature_columns = ['掺量', '冲击速度']
target_column = '能量'

# 处理数据
data = df[feature_columns + [target_column]].dropna()
X = data[feature_columns].copy()
y = data[target_column].copy()

# 确保所有特征都是数值型
X = X.apply(pd.to_numeric, errors='coerce')
y = pd.to_numeric(y, errors='coerce')

# 处理无效值并对齐长度
X = X.replace([np.inf, -np.inf], np.nan).dropna()
y = y.replace([np.inf, -np.inf], np.nan).dropna()
min_len = min(len(X), len(y))
X, y = X.iloc[:min_len], y.iloc[:min_len]

print(f"数据集大小: {X.shape}")
print(f"特征列: {list(X.columns)}")
print(f"目标列: {target_column}")

# 划分训练集和测试集
X_train_val, X_test, y_train_val, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print("\n训练集大小:", X_train_val.shape)
print("测试集大小:", X_test.shape)

# 标准化
scaler_X = StandardScaler()
X_train_val_scaled = scaler_X.fit_transform(X_train_val)
X_test_scaled = scaler_X.transform(X_test)

# 线性回归不需要对目标变量进行标准化
y_train_val_values = y_train_val.values
y_test_values = y_test.values

print("="*60)
print("Linear Regression Model - Predicting Dynamic Compressive Strength")
print("="*60)

# 计算评估指标的函数
def calculate_metrics(y_true, y_pred):
    mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    
    # 计算MAPE，避免除零
    mask = y_true != 0
    if np.sum(mask) > 0:
        mape = np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100
    else:
        mape = 0
        
    return {'MSE': mse, 'RMSE': rmse, 'MAE': mae, 'R2': r2, 'MAPE': mape}

# 定义 5 折交叉验证
kf = KFold(n_splits=5, shuffle=True, random_state=42)

# 手动进行交叉验证并记录每一折的结果
print("\nStarting cross-validation and recording results for each fold...")
fold_results = []
fold_metrics = []

# 用于存储学习曲线数据
learning_curves = {
    'train_rmse': [],
    'val_rmse': [],
    'train_r2': [],
    'val_r2': []
}

for fold, (train_idx, val_idx) in enumerate(kf.split(X_train_val_scaled), 1):
    # 划分训练集和验证集
    X_fold_train, X_fold_val = X_train_val_scaled[train_idx], X_train_val_scaled[val_idx]
    y_fold_train, y_fold_val = y_train_val_values[train_idx], y_train_val_values[val_idx]
    
    # 存储每个fold的学习曲线数据
    fold_train_rmse = []
    fold_val_rmse = []
    fold_train_r2 = []
    fold_val_r2 = []
    
    # 逐步增加训练数据量并记录性能
    train_sizes = np.linspace(0.1, 1.0, 20)  # 从10%到100%的训练数据
    
    for size in train_sizes:
        # 计算当前训练集大小
        n_samples = int(len(X_fold_train) * size)
        
        # 如果训练样本数为0，跳过
        if n_samples == 0:
            continue
            
        # 选择前n_samples个样本
        X_subset = X_fold_train[:n_samples]
        y_subset = y_fold_train[:n_samples]
        
        # 训练线性回归模型
        lr_fold = LinearRegression()
        lr_fold.fit(X_subset, y_subset)
        
        # 训练集预测
        y_fold_train_pred = lr_fold.predict(X_subset)
        train_rmse = np.sqrt(mean_squared_error(y_subset, y_fold_train_pred))
        train_r2 = r2_score(y_subset, y_fold_train_pred)
        
        # 验证集预测
        y_fold_val_pred = lr_fold.predict(X_fold_val)
        val_rmse = np.sqrt(mean_squared_error(y_fold_val, y_fold_val_pred))
        val_r2 = r2_score(y_fold_val, y_fold_val_pred)
        
        fold_train_rmse.append(train_rmse)
        fold_val_rmse.append(val_rmse)
        fold_train_r2.append(train_r2)
        fold_val_r2.append(val_r2)
    
    # 存储当前fold的学习曲线
    learning_curves['train_rmse'].append(fold_train_rmse)
    learning_curves['val_rmse'].append(fold_val_rmse)
    learning_curves['train_r2'].append(fold_train_r2)
    learning_curves['val_r2'].append(fold_val_r2)
    
    # 使用完整训练集进行最终预测
    lr_fold = LinearRegression()
    lr_fold.fit(X_fold_train, y_fold_train)
    y_fold_pred = lr_fold.predict(X_fold_val)
    
    # 计算指标
    metrics = calculate_metrics(y_fold_val, y_fold_pred)
    
    # 记录结果
    fold_results.append({
        'Fold': fold,
        'MSE': metrics['MSE'],
        'RMSE': metrics['RMSE'],
        'MAE': metrics['MAE'],
        'R2': metrics['R2'],
        'MAPE': metrics['MAPE']
    })
    
    fold_metrics.append(metrics)
    
    print(f"Fold {fold} - MSE: {metrics['MSE']:.4f}, RMSE: {metrics['RMSE']:.4f}, "
          f"MAE: {metrics['MAE']:.4f}, R²: {metrics['R2']:.4f}, MAPE: {metrics['MAPE']:.2f}%")

# 计算平均指标
avg_metrics = {
    'MSE': np.mean([m['MSE'] for m in fold_metrics]),
    'RMSE': np.mean([m['RMSE'] for m in fold_metrics]),
    'MAE': np.mean([m['MAE'] for m in fold_metrics]),
    'R2': np.mean([m['R2'] for m in fold_metrics]),
    'MAPE': np.mean([m['MAPE'] for m in fold_metrics])
}

print(f"\nCross-validation average results - MSE: {avg_metrics['MSE']:.4f}, RMSE: {avg_metrics['RMSE']:.4f}, "
      f"MAE: {avg_metrics['MAE']:.4f}, R²: {avg_metrics['R2']:.4f}, MAPE: {avg_metrics['MAPE']:.2f}%")

# 绘制K折学习曲线
print("\nPlotting K-fold cross-validation learning curves...")
train_sizes_percent = np.linspace(0.1, 1.0, 20) * 100

# 计算平均学习曲线和标准差
avg_train_rmse = np.mean(learning_curves['train_rmse'], axis=0)
avg_val_rmse = np.mean(learning_curves['val_rmse'], axis=0)
avg_train_r2 = np.mean(learning_curves['train_r2'], axis=0)
avg_val_r2 = np.mean(learning_curves['val_r2'], axis=0)

# 计算标准差
std_train_rmse = np.std(learning_curves['train_rmse'], axis=0)
std_val_rmse = np.std(learning_curves['val_rmse'], axis=0)
std_train_r2 = np.std(learning_curves['train_r2'], axis=0)
std_val_r2 = np.std(learning_curves['val_r2'], axis=0)

# 创建学习曲线图
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 5))

# RMSE学习曲线
ax1.plot(train_sizes_percent, avg_train_rmse, 'b-', label='Training RMSE', linewidth=2)
ax1.fill_between(train_sizes_percent, 
                avg_train_rmse - std_train_rmse, 
                avg_train_rmse + std_train_rmse, 
                alpha=0.2, color='b')
ax1.plot(train_sizes_percent, avg_val_rmse, 'r-', label='Validation RMSE', linewidth=2)
ax1.fill_between(train_sizes_percent, 
                avg_val_rmse - std_val_rmse, 
                avg_val_rmse + std_val_rmse, 
                alpha=0.2, color='r')
ax1.set_xlabel('Training Set Size (%)')
ax1.set_ylabel('RMSE')
ax1.set_title('Linear Regression RMSE Learning Curve (K-fold Mean ± Std)')
ax1.legend()
ax1.grid(True, alpha=0.3)

# R²学习曲线
ax2.plot(train_sizes_percent, avg_train_r2, 'b-', label='Training R²', linewidth=2)
ax2.fill_between(train_sizes_percent, 
                avg_train_r2 - std_train_r2, 
                avg_train_r2 + std_train_r2, 
                alpha=0.2, color='b')
ax2.plot(train_sizes_percent, avg_val_r2, 'r-', label='Validation R²', linewidth=2)
ax2.fill_between(train_sizes_percent, 
                avg_val_r2 - std_val_r2, 
                avg_val_r2 + std_val_r2, 
                alpha=0.2, color='r')
ax2.set_xlabel('Training Set Size (%)')
ax2.set_ylabel('R² Score')
ax2.set_title('Linear Regression R² Learning Curve (K-fold Mean ± Std)')
ax2.legend()
ax2.grid(True, alpha=0.3)

plt.tight_layout()
learning_curve_path = os.path.join(output_dir, 'LR_K-fold_Learning_Curves.png')
plt.savefig(learning_curve_path, dpi=300, bbox_inches='tight')
plt.show()

print(f"K-fold learning curves saved to: {learning_curve_path}")

# 保存学习曲线数据（包含标准差）
learning_curve_df = pd.DataFrame({
    'training_set_size_percent': train_sizes_percent,
    'avg_train_rmse': avg_train_rmse,
    'std_train_rmse': std_train_rmse,
    'avg_val_rmse': avg_val_rmse,
    'std_val_rmse': std_val_rmse,
    'avg_train_r2': avg_train_r2,
    'std_train_r2': std_train_r2,
    'avg_val_r2': avg_val_r2,
    'std_val_r2': std_val_r2
})
learning_curve_df.to_excel(os.path.join(output_dir, 'LR_Learning_Curve_Data.xlsx'), index=False)

# 找出最佳训练集大小（验证集RMSE最小）
best_train_size_rmse = train_sizes_percent[np.argmin(avg_val_rmse)]
best_rmse = np.min(avg_val_rmse)
print(f"\nOptimal training set size based on validation RMSE: {best_train_size_rmse:.1f}% (RMSE: {best_rmse:.4f})")

# 找出最佳训练集大小（验证集R²最大）
best_train_size_r2 = train_sizes_percent[np.argmax(avg_val_r2)]
best_r2 = np.max(avg_val_r2)
print(f"Optimal training set size based on validation R²: {best_train_size_r2:.1f}% (R²: {best_r2:.4f})")

# 创建并训练最终的线性回归模型（在整个训练集上）
lr_model = LinearRegression()
lr_model.fit(X_train_val_scaled, y_train_val_values)

print("\nModel training completed!")

# 预测
y_pred_train = lr_model.predict(X_train_val_scaled)
y_pred_test = lr_model.predict(X_test_scaled)

# 计算评估指标
train_metrics = calculate_metrics(y_train_val_values, y_pred_train)
test_metrics = calculate_metrics(y_test_values, y_pred_test)

# 输出结果
print("\nTraining set evaluation results:")
print(f"MSE: {train_metrics['MSE']:.4f}, RMSE: {train_metrics['RMSE']:.4f}, "
      f"MAE: {train_metrics['MAE']:.4f}, R²: {train_metrics['R2']:.4f}, MAPE: {train_metrics['MAPE']:.2f}%")

print("\nTest set evaluation results:")
print(f"MSE: {test_metrics['MSE']:.4f}, RMSE: {test_metrics['RMSE']:.4f}, "
      f"MAE: {test_metrics['MAE']:.4f}, R²: {test_metrics['R2']:.4f}, MAPE: {test_metrics['MAPE']:.2f}%")

# 保存预测结果
predictions = pd.DataFrame({
    'Sample Type': ['Training'] * len(y_train_val_values) + ['Test'] * len(y_test_values),
    'True Value': np.concatenate([y_train_val_values, y_test_values]),
    'Predicted Value': np.concatenate([y_pred_train, y_pred_test]),
    'Error': np.concatenate([y_pred_train - y_train_val_values, y_pred_test - y_test_values])
})

# 保存到Excel
output_path = os.path.join(output_dir, 'LinearRegression_能量.xlsx')
with pd.ExcelWriter(output_path) as writer:
    # 评估指标
    metrics_df = pd.DataFrame({
        'Metric': ['MSE', 'RMSE', 'MAE', 'R²', 'MAPE(%)'],
        'Training Set': [train_metrics['MSE'], train_metrics['RMSE'], train_metrics['MAE'], 
                 train_metrics['R2'], train_metrics['MAPE']],
        'Test Set': [test_metrics['MSE'], test_metrics['RMSE'], test_metrics['MAE'], 
                 test_metrics['R2'], test_metrics['MAPE']]
    })
    metrics_df.to_excel(writer, sheet_name='Evaluation Metrics', index=False)
    
    # 预测详情
    predictions.to_excel(writer, sheet_name='Prediction Details', index=False)
    
    # 模型参数
    params_df = pd.DataFrame({
        'Parameter': ['fit_intercept'],
        'Value': [lr_model.fit_intercept_]
    })
    params_df.to_excel(writer, sheet_name='Model Parameters', index=False)
    
    # 每一折的交叉验证结果
    fold_results_df = pd.DataFrame(fold_results)
    fold_results_df.to_excel(writer, sheet_name='Cross-Validation Results', index=False)
    
    # 学习曲线数据
    learning_curve_df.to_excel(writer, sheet_name='Learning Curve Data', index=False)

print(f"\nResults saved to: {output_path}")

# 性能总结
overfit_degree = train_metrics['R2'] - test_metrics['R2']
print("\n" + "="*60)
print("Model Performance Summary")
print("="*60)
print(f"Training R²: {train_metrics['R2']:.4f}")
print(f"Test R²: {test_metrics['R2']:.4f}")
print(f"Training MAPE: {train_metrics['MAPE']:.2f}%")
print(f"Test MAPE: {test_metrics['MAPE']:.2f}%")
print(f"Overfitting degree: {overfit_degree:.4f}")

if overfit_degree > 0.2:
    print("⚠️  Warning: Significant overfitting detected!")
elif overfit_degree > 0.1:
    print("⚠️  Note: Slight overfitting detected")
else:
    print("✅ Good generalization ability")

# 添加额外的模型评估
print("\n" + "="*60)
print("Additional Evaluation Metrics")
print("="*60)

# 计算额外指标
from scipy.stats import pearsonr

# 相关系数
train_corr, _ = pearsonr(y_train_val_values, y_pred_train)
test_corr, _ = pearsonr(y_test_values, y_pred_test)

print(f"Training set correlation coefficient: {train_corr:.4f}")
print(f"Test set correlation coefficient: {test_corr:.4f}")

# 计算预测偏差
train_bias = np.mean(y_pred_train - y_train_val_values)
test_bias = np.mean(y_pred_test - y_test_values)

print(f"Training set mean bias: {train_bias:.4f}")
print(f"Test set mean bias: {test_bias:.4f}")

# 模型系数分析
print("\n" + "="*60)
print("Model Coefficient Analysis")
print("="*60)

coefficients = lr_model.coef_
for feature, coef in zip(feature_columns, coefficients):
    print(f"{feature} coefficient: {coef:.4f}")

print(f"Intercept: {lr_model.intercept_:.4f}")

# 保存系数信息
coef_df = pd.DataFrame({
    'Feature': feature_columns + ['Intercept'],
    'Coefficient': list(coefficients) + [lr_model.intercept_]
})
coef_df.to_excel(os.path.join(output_dir, 'LinearRegression_Model_Coefficients.xlsx'), index=False)

# 模型方程
print("\n" + "="*60)
print("Linear Regression Equation")
print("="*60)
equation = f"y = {lr_model.intercept_:.4f}"
for feature, coef in zip(feature_columns, coefficients):
    equation += f" + {coef:.4f} * {feature}"
print(f"Regression equation: {equation}")

# 保存回归方程
equation_df = pd.DataFrame({
    'Item': ['Regression Equation'],
    'Value': [equation]
})
equation_df.to_excel(os.path.join(output_dir, 'LinearRegression_Regression_Equation.xlsx'), index=False)

# 特征重要性（基于系数绝对值）
print("\n" + "="*60)
print("Feature Importance (based on coefficient absolute values)")
print("="*60)
feature_importance = np.abs(coefficients)
for feature, importance in zip(feature_columns, feature_importance):
    print(f"{feature}: {importance:.4f}")

# 保存特征重要性
importance_df = pd.DataFrame({
    'Feature': feature_columns,
    'Importance': feature_importance
}).sort_values('Importance', ascending=False)
importance_df.to_excel(os.path.join(output_dir, 'LinearRegression_Feature_Importance.xlsx'), index=False)

# 残差分析
print("\n" + "="*60)
print("Residual Analysis")
print("="*60)
train_residuals = y_train_val_values - y_pred_train
test_residuals = y_test_values - y_pred_test

print(f"Training set residual mean: {np.mean(train_residuals):.4f}")
print(f"Training set residual std: {np.std(train_residuals):.4f}")
print(f"Test set residual mean: {np.mean(test_residuals):.4f}")
print(f"Test set residual std: {np.std(test_residuals):.4f}")

# 保存残差分析
residuals_df = pd.DataFrame({
    'Dataset': ['Training Set', 'Test Set'],
    'Residual Mean': [np.mean(train_residuals), np.mean(test_residuals)],
    'Residual Std': [np.std(train_residuals), np.std(test_residuals)]
})
residuals_df.to_excel(os.path.join(output_dir, 'LinearRegression_Residual_Analysis.xlsx'), index=False)