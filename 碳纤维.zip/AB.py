import pandas as pd
import numpy as np
import os
from sklearn.ensemble import AdaBoostRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import train_test_split, KFold, RandomizedSearchCV
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')

# 创建保存结果的目录
output_dir = r"E:\课题组\碳纤维\AdaBoost结果"
os.makedirs(output_dir, exist_ok=True)

# 读取数据
df = pd.read_excel('E:\课题组\碳纤维\碳纤维数据集（25行）.xlsx')

# 选择特征和目标变量 - 预测动态抗压强度
feature_columns = ['掺量', '冲击速度']
target_column = '动态抗压强度'

# 处理数据
data = df[feature_columns + [target_column]].dropna()
X = data[feature_columns].copy()
y = data[target_column].copy()

# 确保所有特征都是数值型
X = X.apply(pd.to_numeric, errors='coerce')
y = pd.to_numeric(y, errors='coerce')

# 处理无效值并对齐长度
X = X.replace([np.inf, -np.inf], np.nan).dropna()
y = y.replace([np.inf, -np.inf], np.nan).dropna()
min_len = min(len(X), len(y))
X, y = X.iloc[:min_len], y.iloc[:min_len]

print(f"数据集大小: {X.shape}")
print(f"特征列: {list(X.columns)}")
print(f"目标列: {target_column}")

# 划分训练集和测试集
X_train_val, X_test, y_train_val, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print("\n训练集大小:", X_train_val.shape)
print("测试集大小:", X_test.shape)

# 标准化
scaler_X = StandardScaler()
X_train_val_scaled = scaler_X.fit_transform(X_train_val)
X_test_scaled = scaler_X.transform(X_test)

# AdaBoost不需要对目标变量进行标准化
y_train_val_values = y_train_val.values
y_test_values = y_test.values

# 定义 5 折交叉验证
kf = KFold(n_splits=5, shuffle=True, random_state=42)

print("="*60)
print("AdaBoost模型 - 预测动态抗压强度")
print("="*60)

# 计算评估指标的函数
def calculate_metrics(y_true, y_pred):
    mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    
    # 计算MAPE，避免除零
    mask = y_true != 0
    if np.sum(mask) > 0:
        mape = np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100
    else:
        mape = 0
        
    return {'MSE': mse, 'RMSE': rmse, 'MAE': mae, 'R2': r2, 'MAPE': mape}

# 手动进行交叉验证并记录每一折的结果
print("\n开始交叉验证并记录每一折结果...")
fold_results = []
fold_metrics = []

# 用于存储学习曲线数据
learning_curves = {
    'train_rmse': [],
    'val_rmse': [],
    'train_r2': [],
    'val_r2': []
}

for fold, (train_idx, val_idx) in enumerate(kf.split(X_train_val_scaled), 1):
    # 划分训练集和验证集
    X_fold_train, X_fold_val = X_train_val_scaled[train_idx], X_train_val_scaled[val_idx]
    y_fold_train, y_fold_val = y_train_val_values[train_idx], y_train_val_values[val_idx]
    
    # 使用默认参数训练模型（后面会替换为搜索到的最佳参数）
    base_estimator_fold = DecisionTreeRegressor(random_state=42)
    ada_fold = AdaBoostRegressor(
        base_estimator=base_estimator_fold,
        random_state=42,
        n_estimators=100  # 固定数量以便绘制学习曲线
    )
    
    # 存储每个fold的学习曲线数据
    fold_train_rmse = []
    fold_val_rmse = []
    fold_train_r2 = []
    fold_val_r2 = []
    
    # 逐步训练并记录性能
    for n_est in range(1, 101):  # 从1到100个估计器
        ada_fold.set_params(n_estimators=n_est)
        ada_fold.fit(X_fold_train, y_fold_train)
        
        # 训练集预测
        y_fold_train_pred = ada_fold.predict(X_fold_train)
        train_rmse = np.sqrt(mean_squared_error(y_fold_train, y_fold_train_pred))
        train_r2 = r2_score(y_fold_train, y_fold_train_pred)
        
        # 验证集预测
        y_fold_val_pred = ada_fold.predict(X_fold_val)
        val_rmse = np.sqrt(mean_squared_error(y_fold_val, y_fold_val_pred))
        val_r2 = r2_score(y_fold_val, y_fold_val_pred)
        
        fold_train_rmse.append(train_rmse)
        fold_val_rmse.append(val_rmse)
        fold_train_r2.append(train_r2)
        fold_val_r2.append(val_r2)
    
    # 存储当前fold的学习曲线
    learning_curves['train_rmse'].append(fold_train_rmse)
    learning_curves['val_rmse'].append(fold_val_rmse)
    learning_curves['train_r2'].append(fold_train_r2)
    learning_curves['val_r2'].append(fold_val_r2)
    
    # 使用完整模型进行最终预测
    ada_fold.set_params(n_estimators=100)
    ada_fold.fit(X_fold_train, y_fold_train)
    y_fold_pred = ada_fold.predict(X_fold_val)
    
    # 计算指标
    metrics = calculate_metrics(y_fold_val, y_fold_pred)
    
    # 记录结果
    fold_results.append({
        'Fold': fold,
        'MSE': metrics['MSE'],
        'RMSE': metrics['RMSE'],
        'MAE': metrics['MAE'],
        'R2': metrics['R2'],
        'MAPE': metrics['MAPE']
    })
    
    fold_metrics.append(metrics)
    
    print(f"第{fold}折 - MSE: {metrics['MSE']:.4f}, RMSE: {metrics['RMSE']:.4f}, "
          f"MAE: {metrics['MAE']:.4f}, R²: {metrics['R2']:.4f}, MAPE: {metrics['MAPE']:.2f}%")

# 计算平均指标
avg_metrics = {
    'MSE': np.mean([m['MSE'] for m in fold_metrics]),
    'RMSE': np.mean([m['RMSE'] for m in fold_metrics]),
    'MAE': np.mean([m['MAE'] for m in fold_metrics]),
    'R2': np.mean([m['R2'] for m in fold_metrics]),
    'MAPE': np.mean([m['MAPE'] for m in fold_metrics])
}

print(f"\n交叉验证平均结果 - MSE: {avg_metrics['MSE']:.4f}, RMSE: {avg_metrics['RMSE']:.4f}, "
      f"MAE: {avg_metrics['MAE']:.4f}, R²: {avg_metrics['R2']:.4f}, MAPE: {avg_metrics['MAPE']:.2f}%")

# 绘制K折学习曲线
print("\n绘制K折交叉验证学习曲线...")
n_estimators_range = range(1, 101)

# 计算平均学习曲线
avg_train_rmse = np.mean(learning_curves['train_rmse'], axis=0)
avg_val_rmse = np.mean(learning_curves['val_rmse'], axis=0)
avg_train_r2 = np.mean(learning_curves['train_r2'], axis=0)
avg_val_r2 = np.mean(learning_curves['val_r2'], axis=0)

# 创建学习曲线图
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 5))

# RMSE学习曲线
ax1.plot(n_estimators_range, avg_train_rmse, 'b-', label='训练集RMSE', linewidth=2)
ax1.plot(n_estimators_range, avg_val_rmse, 'r-', label='验证集RMSE', linewidth=2)
ax1.set_xlabel('弱学习器数量')
ax1.set_ylabel('RMSE')
ax1.set_title('AdaBoost RMSE学习曲线 (K折平均)')
ax1.legend()
ax1.grid(True, alpha=0.3)

# R²学习曲线
ax2.plot(n_estimators_range, avg_train_r2, 'b-', label='训练集R²', linewidth=2)
ax2.plot(n_estimators_range, avg_val_r2, 'r-', label='验证集R²', linewidth=2)
ax2.set_xlabel('弱学习器数量')
ax2.set_ylabel('R² Score')
ax2.set_title('AdaBoost R²学习曲线 (K折平均)')
ax2.legend()
ax2.grid(True, alpha=0.3)

plt.tight_layout()
learning_curve_path = os.path.join(output_dir, 'AdaBoost_K折学习曲线.png')
plt.savefig(learning_curve_path, dpi=300, bbox_inches='tight')
plt.show()

print(f"K折学习曲线已保存至: {learning_curve_path}")

# 保存学习曲线数据
learning_curve_df = pd.DataFrame({
    'n_estimators': n_estimators_range,
    'avg_train_rmse': avg_train_rmse,
    'avg_val_rmse': avg_val_rmse,
    'avg_train_r2': avg_train_r2,
    'avg_val_r2': avg_val_r2
})
learning_curve_df.to_excel(os.path.join(output_dir, 'AdaBoost_学习曲线数据.xlsx'), index=False)

# 找出最佳弱学习器数量（验证集RMSE最小）
best_n_estimators_rmse = n_estimators_range[np.argmin(avg_val_rmse)]
best_rmse = np.min(avg_val_rmse)
print(f"\n基于验证集RMSE的最佳弱学习器数量: {best_n_estimators_rmse} (RMSE: {best_rmse:.4f})")

# 找出最佳弱学习器数量（验证集R²最大）
best_n_estimators_r2 = n_estimators_range[np.argmax(avg_val_r2)]
best_r2 = np.max(avg_val_r2)
print(f"基于验证集R²的最佳弱学习器数量: {best_n_estimators_r2} (R²: {best_r2:.4f})")

# AdaBoost的超参数搜索空间
param_dist = {
    'n_estimators': [50, 100, 150, 200, 300],
    'learning_rate': [0.001, 0.01, 0.05, 0.1, 0.2, 0.5, 1.0, 1.5, 2.0],
    'loss': ['linear', 'square', 'exponential'],
    # 基学习器参数
    'base_estimator__max_depth': [1, 2, 3, 4, 5],
    'base_estimator__min_samples_split': [2, 3, 4, 5],
    'base_estimator__min_samples_leaf': [1, 2, 3, 4]
}

# 创建基学习器
base_estimator = DecisionTreeRegressor(random_state=42)

# 创建AdaBoost回归器
ada = AdaBoostRegressor(
    base_estimator=base_estimator,
    random_state=42
)

random_search = RandomizedSearchCV(
    estimator=ada,
    param_distributions=param_dist,
    n_iter=50,  # 搜索迭代次数
    cv=kf,
    scoring='r2',
    random_state=42,
    n_jobs=-1
)

print("\n开始超参数搜索...")
random_search.fit(X_train_val_scaled, y_train_val_values)
best_model = random_search.best_estimator_
best_params = random_search.best_params_
print("最佳超参数:", best_params)

# 预测
y_pred_train = best_model.predict(X_train_val_scaled)
y_pred_test = best_model.predict(X_test_scaled)

train_metrics = calculate_metrics(y_train_val_values, y_pred_train)
test_metrics = calculate_metrics(y_test_values, y_pred_test)

# 输出结果
print("\n训练集评估结果：")
print(f"MSE: {train_metrics['MSE']:.4f}, RMSE: {train_metrics['RMSE']:.4f}, "
      f"MAE: {train_metrics['MAE']:.4f}, R²: {train_metrics['R2']:.4f}, MAPE: {train_metrics['MAPE']:.2f}%")

print("\n测试集评估结果：")
print(f"MSE: {test_metrics['MSE']:.4f}, RMSE: {test_metrics['RMSE']:.4f}, "
      f"MAE: {test_metrics['MAE']:.4f}, R²: {test_metrics['R2']:.4f}, MAPE: {test_metrics['MAPE']:.2f}%")

# 保存预测结果
predictions = pd.DataFrame({
    '样本类型': ['训练集'] * len(y_train_val_values) + ['测试集'] * len(y_test_values),
    '真实值': np.concatenate([y_train_val_values, y_test_values]),
    '预测值': np.concatenate([y_pred_train, y_pred_test]),
    '误差': np.concatenate([y_pred_train - y_train_val_values, y_pred_test - y_test_values])
})

# 保存到Excel
output_path = os.path.join(output_dir, 'AdaBoost_动态抗压强度预测结果.xlsx')
with pd.ExcelWriter(output_path) as writer:
    # 评估指标
    metrics_df = pd.DataFrame({
        '评估指标': ['MSE', 'RMSE', 'MAE', 'R²', 'MAPE(%)'],
        '训练集': [train_metrics['MSE'], train_metrics['RMSE'], train_metrics['MAE'], 
                 train_metrics['R2'], train_metrics['MAPE']],
        '测试集': [test_metrics['MSE'], test_metrics['RMSE'], test_metrics['MAE'], 
                 test_metrics['R2'], test_metrics['MAPE']]
    })
    metrics_df.to_excel(writer, sheet_name='评估指标', index=False)
    
    # 预测详情
    predictions.to_excel(writer, sheet_name='预测详情', index=False)
    
    # 最佳参数
    params_df = pd.DataFrame(list(best_params.items()), columns=['参数', '值'])
    params_df.to_excel(writer, sheet_name='最佳参数', index=False)
    
    # 每一折的交叉验证结果
    fold_results_df = pd.DataFrame(fold_results)
    fold_results_df.to_excel(writer, sheet_name='交叉验证结果', index=False)
    
    # 学习曲线数据
    learning_curve_df.to_excel(writer, sheet_name='学习曲线数据', index=False)

print(f"\n结果已保存至: {output_path}")

# 性能总结
overfit_degree = train_metrics['R2'] - test_metrics['R2']
print("\n" + "="*60)
print("模型性能总结")
print("="*60)
print(f"训练集R²: {train_metrics['R2']:.4f}")
print(f"测试集R²: {test_metrics['R2']:.4f}")
print(f"训练集MAPE: {train_metrics['MAPE']:.2f}%")
print(f"测试集MAPE: {test_metrics['MAPE']:.2f}%")
print(f"过拟合程度: {overfit_degree:.4f}")

if overfit_degree > 0.2:
    print("⚠️  警告：模型存在明显过拟合！")
elif overfit_degree > 0.1:
    print("⚠️  注意：模型存在轻微过拟合")
else:
    print("✅ 模型泛化能力良好")

# 添加额外的模型评估
print("\n" + "="*60)
print("额外评估指标")
print("="*60)

# 计算额外指标
from scipy.stats import pearsonr

# 相关系数
train_corr, _ = pearsonr(y_train_val_values, y_pred_train)
test_corr, _ = pearsonr(y_test_values, y_pred_test)

print(f"训练集相关系数: {train_corr:.4f}")
print(f"测试集相关系数: {test_corr:.4f}")

# 计算预测偏差
train_bias = np.mean(y_pred_train - y_train_val_values)
test_bias = np.mean(y_pred_test - y_test_values)

print(f"训练集平均偏差: {train_bias:.4f}")
print(f"测试集平均偏差: {test_bias:.4f}")

# 特征重要性
print("\n" + "="*60)
print("特征重要性")
print("="*60)
feature_importance = best_model.feature_importances_
for feature, importance in zip(feature_columns, feature_importance):
    print(f"{feature}: {importance:.4f}")

# 保存特征重要性
importance_df = pd.DataFrame({
    '特征': feature_columns,
    '重要性': feature_importance
}).sort_values('重要性', ascending=False)
importance_df.to_excel(os.path.join(output_dir, 'AdaBoost_特征重要性.xlsx'), index=False)

# 学习器权重分析
print("\n" + "="*60)
print("弱学习器权重分析")
print("="*60)
print(f"弱学习器数量: {len(best_model.estimators_)}")
print(f"弱学习器权重均值: {np.mean(best_model.estimator_weights_):.4f}")
print(f"弱学习器权重标准差: {np.std(best_model.estimator_weights_):.4f}")
print(f"弱学习器权重范围: [{np.min(best_model.estimator_weights_):.4f}, {np.max(best_model.estimator_weights_):.4f}]")

# 保存弱学习器权重
estimator_weights_df = pd.DataFrame({
    '弱学习器索引': range(len(best_model.estimator_weights_)),
    '权重': best_model.estimator_weights_
}).sort_values('权重', ascending=False)
estimator_weights_df.to_excel(os.path.join(output_dir, 'AdaBoost_弱学习器权重.xlsx'), index=False)
# 设置全局字体为新罗马
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 12

# 绘制K折学习曲线
print("\nPlotting K-fold cross-validation learning curves...")
n_estimators_range = range(1, 101)

# 计算平均学习曲线和标准差
avg_train_rmse = np.mean(learning_curves['train_rmse'], axis=0)
avg_val_rmse = np.mean(learning_curves['val_rmse'], axis=0)
avg_train_r2 = np.mean(learning_curves['train_r2'], axis=0)
avg_val_r2 = np.mean(learning_curves['val_r2'], axis=0)

# 计算标准差
std_train_rmse = np.std(learning_curves['train_rmse'], axis=0)
std_val_rmse = np.std(learning_curves['val_rmse'], axis=0)
std_train_r2 = np.std(learning_curves['train_r2'], axis=0)
std_val_r2 = np.std(learning_curves['val_r2'], axis=0)

# 创建学习曲线图
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 5))

# RMSE学习曲线
ax1.plot(n_estimators_range, avg_train_rmse, 'b-', label='Training RMSE', linewidth=2)
ax1.fill_between(n_estimators_range, 
                avg_train_rmse - std_train_rmse, 
                avg_train_rmse + std_train_rmse, 
                alpha=0.2, color='b')
ax1.plot(n_estimators_range, avg_val_rmse, 'r-', label='Validation RMSE', linewidth=2)
ax1.fill_between(n_estimators_range, 
                avg_val_rmse - std_val_rmse, 
                avg_val_rmse + std_val_rmse, 
                alpha=0.2, color='r')
ax1.set_xlabel('Number of Weak Learners')
ax1.set_ylabel('RMSE')
ax1.set_title('AdaBoost RMSE Learning Curve (K-fold Mean ± Std)')
ax1.legend()
ax1.grid(True, alpha=0.3)

# R²学习曲线
ax2.plot(n_estimators_range, avg_train_r2, 'b-', label='Training R²', linewidth=2)
ax2.fill_between(n_estimators_range, 
                avg_train_r2 - std_train_r2, 
                avg_train_r2 + std_train_r2, 
                alpha=0.2, color='b')
ax2.plot(n_estimators_range, avg_val_r2, 'r-', label='Validation R²', linewidth=2)
ax2.fill_between(n_estimators_range, 
                avg_val_r2 - std_val_r2, 
                avg_val_r2 + std_val_r2, 
                alpha=0.2, color='r')
ax2.set_xlabel('Number of Weak Learners')
ax2.set_ylabel('R² Score')
ax2.set_title('AdaBoost R² Learning Curve (K-fold Mean ± Std)')
ax2.legend()
ax2.grid(True, alpha=0.3)

plt.tight_layout()
learning_curve_path = os.path.join(output_dir, 'AdaBoost_K-fold_Learning_Curves.png')
plt.savefig(learning_curve_path, dpi=300, bbox_inches='tight')
plt.show()

print(f"K-fold learning curves saved to: {learning_curve_path}")

# 保存学习曲线数据（包含标准差）
learning_curve_df = pd.DataFrame({
    'n_estimators': n_estimators_range,
    'avg_train_rmse': avg_train_rmse,
    'std_train_rmse': std_train_rmse,
    'avg_val_rmse': avg_val_rmse,
    'std_val_rmse': std_val_rmse,
    'avg_train_r2': avg_train_r2,
    'std_train_r2': std_train_r2,
    'avg_val_r2': avg_val_r2,
    'std_val_r2': std_val_r2
})
learning_curve_df.to_excel(os.path.join(output_dir, 'AdaBoost_Learning_Curve_Data.xlsx'), index=False)