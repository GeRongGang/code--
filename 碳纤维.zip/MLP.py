import pandas as pd
import numpy as np
import os
import matplotlib.pyplot as plt
from sklearn.neural_network import MLPRegressor
from sklearn.model_selection import train_test_split, KFold, RandomizedSearchCV
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.preprocessing import StandardScaler
import warnings
warnings.filterwarnings('ignore')

# Set global font to Times New Roman
plt.rcParams['font.family'] = 'Times New Roman'
plt.rcParams['font.size'] = 12

# Create output directory
output_dir = r"E:\课题组\碳纤维\MLP结果"
os.makedirs(output_dir, exist_ok=True)

# Read data
df = pd.read_excel('E:\课题组\碳纤维\碳纤维数据集（25行）.xlsx')

# Select features and target variable - predict dynamic compressive strength
feature_columns = ['掺量', '冲击速度']
target_column = '动态抗压强度'

# Process data
data = df[feature_columns + [target_column]].dropna()
X = data[feature_columns].copy()
y = data[target_column].copy()

# Ensure all features are numeric
X = X.apply(pd.to_numeric, errors='coerce')
y = pd.to_numeric(y, errors='coerce')

# Handle invalid values and align length
X = X.replace([np.inf, -np.inf], np.nan).dropna()
y = y.replace([np.inf, -np.inf], np.nan).dropna()
min_len = min(len(X), len(y))
X, y = X.iloc[:min_len], y.iloc[:min_len]

print(f"Dataset size: {X.shape}")
print(f"Feature columns: {list(X.columns)}")
print(f"Target column: {target_column}")

# Split training and test sets
X_train_val, X_test, y_train_val, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print("\nTraining set size:", X_train_val.shape)
print("Test set size:", X_test.shape)

# Standardization
scaler_X = StandardScaler()
X_train_val_scaled = scaler_X.fit_transform(X_train_val)
X_test_scaled = scaler_X.transform(X_test)

scaler_y = StandardScaler()
y_train_val_scaled = scaler_y.fit_transform(y_train_val.values.reshape(-1, 1)).ravel()
y_test_scaled = scaler_y.transform(y_test.values.reshape(-1, 1)).ravel()

# Define 5-fold cross validation
kf = KFold(n_splits=5, shuffle=True, random_state=42)

print("="*60)
print("MLP Model - Predicting Dynamic Compressive Strength")
print("="*60)

# Function to calculate evaluation metrics
def calculate_metrics(y_true, y_pred):
    mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    
    # Calculate MAPE, avoid division by zero
    mask = y_true != 0
    if np.sum(mask) > 0:
        mape = np.mean(np.abs((y_true[mask] - y_pred[mask]) / y_true[mask])) * 100
    else:
        mape = 0
        
    return {'MSE': mse, 'RMSE': rmse, 'MAE': mae, 'R2': r2, 'MAPE': mape}

# Manual cross-validation and record results for each fold
print("\nStarting cross-validation and recording results for each fold...")
fold_results = []
fold_metrics = []

# For storing learning curve data
learning_curves = {
    'train_rmse': [],
    'val_rmse': [],
    'train_r2': [],
    'val_r2': []
}

for fold, (train_idx, val_idx) in enumerate(kf.split(X_train_val_scaled), 1):
    # Split training and validation sets
    X_fold_train, X_fold_val = X_train_val_scaled[train_idx], X_train_val_scaled[val_idx]
    y_fold_train, y_fold_val = y_train_val_scaled[train_idx], y_train_val_scaled[val_idx]
    
    # Train model with default parameters (will be replaced with best parameters later)
    mlp_fold = MLPRegressor(random_state=42, max_iter=1000)
    
    # Store learning curve data for each fold
    fold_train_rmse = []
    fold_val_rmse = []
    fold_train_r2 = []
    fold_val_r2 = []
    
    # Progressive training and performance recording
    for epoch in range(50, 1001, 50):  # From 50 to 1000 epochs, record every 50
        mlp_fold.set_params(max_iter=epoch)
        mlp_fold.fit(X_fold_train, y_fold_train)
        
        # Training set prediction
        y_fold_train_pred_scaled = mlp_fold.predict(X_fold_train)
        y_fold_train_pred = scaler_y.inverse_transform(y_fold_train_pred_scaled.reshape(-1, 1)).ravel()
        y_fold_train_true = scaler_y.inverse_transform(y_fold_train.reshape(-1, 1)).ravel()
        
        train_rmse = np.sqrt(mean_squared_error(y_fold_train_true, y_fold_train_pred))
        train_r2 = r2_score(y_fold_train_true, y_fold_train_pred)
        
        # Validation set prediction
        y_fold_val_pred_scaled = mlp_fold.predict(X_fold_val)
        y_fold_val_pred = scaler_y.inverse_transform(y_fold_val_pred_scaled.reshape(-1, 1)).ravel()
        y_fold_val_true = scaler_y.inverse_transform(y_fold_val.reshape(-1, 1)).ravel()
        
        val_rmse = np.sqrt(mean_squared_error(y_fold_val_true, y_fold_val_pred))
        val_r2 = r2_score(y_fold_val_true, y_fold_val_pred)
        
        fold_train_rmse.append(train_rmse)
        fold_val_rmse.append(val_rmse)
        fold_train_r2.append(train_r2)
        fold_val_r2.append(val_r2)
    
    # Store current fold's learning curve
    learning_curves['train_rmse'].append(fold_train_rmse)
    learning_curves['val_rmse'].append(fold_val_rmse)
    learning_curves['train_r2'].append(fold_train_r2)
    learning_curves['val_r2'].append(fold_val_r2)
    
    # Use complete model for final prediction
    mlp_fold.set_params(max_iter=1000)
    mlp_fold.fit(X_fold_train, y_fold_train)
    
    # Prediction
    y_fold_pred_scaled = mlp_fold.predict(X_fold_val)
    
    # Convert predictions back to original scale
    y_fold_pred = scaler_y.inverse_transform(y_fold_pred_scaled.reshape(-1, 1)).ravel()
    y_fold_true = scaler_y.inverse_transform(y_fold_val.reshape(-1, 1)).ravel()
    
    # Calculate metrics
    metrics = calculate_metrics(y_fold_true, y_fold_pred)
    
    # Record results
    fold_results.append({
        'Fold': fold,
        'MSE': metrics['MSE'],
        'RMSE': metrics['RMSE'],
        'MAE': metrics['MAE'],
        'R2': metrics['R2'],
        'MAPE': metrics['MAPE']
    })
    
    fold_metrics.append(metrics)
    
    print(f"Fold {fold} - MSE: {metrics['MSE']:.4f}, RMSE: {metrics['RMSE']:.4f}, "
          f"MAE: {metrics['MAE']:.4f}, R²: {metrics['R2']:.4f}, MAPE: {metrics['MAPE']:.2f}%")

# Calculate mean and standard deviation of K-fold cross-validation results
print("\n" + "="*60)
print("K-fold Cross-validation Results Statistics (Mean ± Std)")
print("="*60)

# Extract metrics from each fold
mse_list = [result['MSE'] for result in fold_results]
rmse_list = [result['RMSE'] for result in fold_results]
mae_list = [result['MAE'] for result in fold_results]
r2_list = [result['R2'] for result in fold_results]
mape_list = [result['MAPE'] for result in fold_results]

# Calculate mean and standard deviation
mse_mean, mse_std = np.mean(mse_list), np.std(mse_list)
rmse_mean, rmse_std = np.mean(rmse_list), np.std(rmse_list)
mae_mean, mae_std = np.mean(mae_list), np.std(mae_list)
r2_mean, r2_std = np.mean(r2_list), np.std(r2_list)
mape_mean, mape_std = np.mean(mape_list), np.std(mape_list)

# Print results
print(f"MSE: {mse_mean:.4f} ± {mse_std:.4f}")
print(f"RMSE: {rmse_mean:.4f} ± {rmse_std:.4f}")
print(f"MAE: {mae_mean:.4f} ± {mae_std:.4f}")
print(f"R²: {r2_mean:.4f} ± {r2_std:.4f}")
print(f"MAPE: {mape_mean:.2f}% ± {mape_std:.2f}%")

# Save K-fold statistics
kfold_stats = pd.DataFrame({
    'Evaluation Metric': ['MSE', 'RMSE', 'MAE', 'R²', 'MAPE(%)'],
    'Mean': [mse_mean, rmse_mean, mae_mean, r2_mean, mape_mean],
    'Std': [mse_std, rmse_std, mae_std, r2_std, mape_std],
    'Representation': [
        f"{mse_mean:.4f} ± {mse_std:.4f}",
        f"{rmse_mean:.4f} ± {rmse_std:.4f}", 
        f"{mae_mean:.4f} ± {mae_std:.4f}",
        f"{r2_mean:.4f} ± {r2_std:.4f}",
        f"{mape_mean:.2f}% ± {mape_std:.2f}%"
    ]
})

# Plot K-fold learning curves
print("\nPlotting K-fold cross-validation learning curves...")
epochs_range = range(50, 1001, 50)

# Calculate average learning curves
avg_train_rmse = np.mean(learning_curves['train_rmse'], axis=0)
avg_val_rmse = np.mean(learning_curves['val_rmse'], axis=0)
avg_train_r2 = np.mean(learning_curves['train_r2'], axis=0)
avg_val_r2 = np.mean(learning_curves['val_r2'], axis=0)

# Calculate standard deviation
std_train_rmse = np.std(learning_curves['train_rmse'], axis=0)
std_val_rmse = np.std(learning_curves['val_rmse'], axis=0)
std_train_r2 = np.std(learning_curves['train_r2'], axis=0)
std_val_r2 = np.std(learning_curves['val_r2'], axis=0)

# Create learning curve plot
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 5))

# RMSE learning curve
ax1.plot(epochs_range, avg_train_rmse, 'b-', label='Training RMSE', linewidth=2)
ax1.fill_between(epochs_range, 
                avg_train_rmse - std_train_rmse, 
                avg_train_rmse + std_train_rmse, 
                alpha=0.2, color='b')
ax1.plot(epochs_range, avg_val_rmse, 'r-', label='Validation RMSE', linewidth=2)
ax1.fill_between(epochs_range, 
                avg_val_rmse - std_val_rmse, 
                avg_val_rmse + std_val_rmse, 
                alpha=0.2, color='r')
ax1.set_xlabel('Epochs')
ax1.set_ylabel('RMSE')
ax1.set_title('MLP RMSE Learning Curve (K-fold Mean ± Std)')
ax1.legend()
ax1.grid(True, alpha=0.3)

# R² learning curve
ax2.plot(epochs_range, avg_train_r2, 'b-', label='Training R²', linewidth=2)
ax2.fill_between(epochs_range, 
                avg_train_r2 - std_train_r2, 
                avg_train_r2 + std_train_r2, 
                alpha=0.2, color='b')
ax2.plot(epochs_range, avg_val_r2, 'r-', label='Validation R²', linewidth=2)
ax2.fill_between(epochs_range, 
                avg_val_r2 - std_val_r2, 
                avg_val_r2 + std_val_r2, 
                alpha=0.2, color='r')
ax2.set_xlabel('Epochs')
ax2.set_ylabel('R² Score')
ax2.set_title('MLP R² Learning Curve (K-fold Mean ± Std)')
ax2.legend()
ax2.grid(True, alpha=0.3)

plt.tight_layout()
learning_curve_path = os.path.join(output_dir, 'MLP_K-fold_Learning_Curves.png')
plt.savefig(learning_curve_path, dpi=300, bbox_inches='tight')
plt.show()

print(f"K-fold learning curves saved to: {learning_curve_path}")

# Save learning curve data
learning_curve_df = pd.DataFrame({
    'epochs': epochs_range,
    'avg_train_rmse': avg_train_rmse,
    'std_train_rmse': std_train_rmse,
    'avg_val_rmse': avg_val_rmse,
    'std_val_rmse': std_val_rmse,
    'avg_train_r2': avg_train_r2,
    'std_train_r2': std_train_r2,
    'avg_val_r2': avg_val_r2,
    'std_val_r2': std_val_r2
})
learning_curve_df.to_excel(os.path.join(output_dir, 'MLP_Learning_Curve_Data.xlsx'), index=False)

# Find best training epoch (minimum validation RMSE)
best_epoch_rmse = epochs_range[np.argmin(avg_val_rmse)]
best_rmse = np.min(avg_val_rmse)
print(f"\nBest training epoch based on validation RMSE: {best_epoch_rmse} (RMSE: {best_rmse:.4f})")

# Find best training epoch (maximum validation R²)
best_epoch_r2 = epochs_range[np.argmax(avg_val_r2)]
best_r2 = np.max(avg_val_r2)
print(f"Best training epoch based on validation R²: {best_epoch_r2} (R²: {best_r2:.4f})")

# Extended hyperparameter search space
param_dist = {
    'hidden_layer_sizes': [(5,), (6,), (7,), (8,), (5, 3), (6, 3), (7, 3), (5, 4), (6, 4)],
    'activation': ['tanh', 'relu', 'logistic'],
    'solver': ['lbfgs', 'adam', 'sgd'],
    'alpha': [0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1.0],
    'learning_rate_init': [0.0005, 0.001, 0.005, 0.01],
    'max_iter': [500, 600, 700, 800],
    'early_stopping': [True],
    'validation_fraction': [0.1, 0.15, 0.2],
    'n_iter_no_change': [15, 20, 25],
    'tol': [1e-5, 1e-4],
    'beta_1': [0.8, 0.9, 0.95],  # Only for adam optimizer
    'beta_2': [0.99, 0.999, 0.9999],  # Only for adam optimizer
    'momentum': [0.8, 0.9, 0.95]  # Only for sgd optimizer
}

mlp = MLPRegressor(random_state=42)
random_search = RandomizedSearchCV(
    estimator=mlp,
    param_distributions=param_dist,
    n_iter=50,  # Increase search iterations
    cv=kf,
    scoring='r2',
    random_state=42,
    n_jobs=-1
)

print("\nStarting hyperparameter search...")
random_search.fit(X_train_val_scaled, y_train_val_scaled)
best_model = random_search.best_estimator_
best_params = random_search.best_params_
print("Best hyperparameters:", best_params)

# Prediction
y_pred_train_scaled = best_model.predict(X_train_val_scaled)
y_pred_train = scaler_y.inverse_transform(y_pred_train_scaled.reshape(-1, 1)).ravel()
y_pred_test_scaled = best_model.predict(X_test_scaled)
y_pred_test = scaler_y.inverse_transform(y_pred_test_scaled.reshape(-1, 1)).ravel()

train_metrics = calculate_metrics(y_train_val, y_pred_train)
test_metrics = calculate_metrics(y_test, y_pred_test)

# Output results
print("\nTraining set evaluation results:")
print(f"MSE: {train_metrics['MSE']:.4f}, RMSE: {train_metrics['RMSE']:.4f}, "
      f"MAE: {train_metrics['MAE']:.4f}, R²: {train_metrics['R2']:.4f}, MAPE: {train_metrics['MAPE']:.2f}%")

print("\nTest set evaluation results:")
print(f"MSE: {test_metrics['MSE']:.4f}, RMSE: {test_metrics['RMSE']:.4f}, "
      f"MAE: {test_metrics['MAE']:.4f}, R²: {test_metrics['R2']:.4f}, MAPE: {test_metrics['MAPE']:.2f}%")

# Save prediction results
predictions = pd.DataFrame({
    'Sample Type': ['Training'] * len(y_train_val) + ['Test'] * len(y_test),
    'True Value': np.concatenate([y_train_val.values, y_test.values]),
    'Predicted Value': np.concatenate([y_pred_train, y_pred_test]),
    'Error': np.concatenate([y_pred_train - y_train_val.values, y_pred_test - y_test.values])
})

# Save to Excel
output_path = os.path.join(output_dir, 'MLP_Dynamic_Compressive_Strength_Prediction_Results.xlsx')
with pd.ExcelWriter(output_path) as writer:
    # Evaluation metrics
    metrics_df = pd.DataFrame({
        'Evaluation Metric': ['MSE', 'RMSE', 'MAE', 'R²', 'MAPE(%)'],
        'Training Set': [train_metrics['MSE'], train_metrics['RMSE'], train_metrics['MAE'], 
                 train_metrics['R2'], train_metrics['MAPE']],
        'Test Set': [test_metrics['MSE'], test_metrics['RMSE'], test_metrics['MAE'], 
                 test_metrics['R2'], test_metrics['MAPE']]
    })
    metrics_df.to_excel(writer, sheet_name='Evaluation Metrics', index=False)
    
    # Prediction details
    predictions.to_excel(writer, sheet_name='Prediction Details', index=False)
    
    # Best parameters
    params_df = pd.DataFrame(list(best_params.items()), columns=['Parameter', 'Value'])
    params_df.to_excel(writer, sheet_name='Best Parameters', index=False)
    
    # Cross-validation results for each fold
    fold_results_df = pd.DataFrame(fold_results)
    fold_results_df.to_excel(writer, sheet_name='Cross-validation Results', index=False)
    
    # K-fold statistics
    kfold_stats.to_excel(writer, sheet_name='K-fold Statistics', index=False)
    
    # Learning curve data
    learning_curve_df.to_excel(writer, sheet_name='Learning Curve Data', index=False)

print(f"\nResults saved to: {output_path}")

# Performance summary
overfit_degree = train_metrics['R2'] - test_metrics['R2']
print("\n" + "="*60)
print("Model Performance Summary")
print("="*60)
print(f"Training R²: {train_metrics['R2']:.4f}")
print(f"Test R²: {test_metrics['R2']:.4f}")
print(f"Training MAPE: {train_metrics['MAPE']:.2f}%")
print(f"Test MAPE: {test_metrics['MAPE']:.2f}%")
print(f"Overfitting degree: {overfit_degree:.4f}")

if overfit_degree > 0.2:
    print("⚠️  Warning: Model shows significant overfitting!")
elif overfit_degree > 0.1:
    print("⚠️  Note: Model shows slight overfitting")
else:
    print("✅ Model generalization ability is good")

# Additional model evaluation
print("\n" + "="*60)
print("Additional Evaluation Metrics")
print("="*60)

# Calculate additional metrics
from scipy.stats import pearsonr

# Correlation coefficient
train_corr, _ = pearsonr(y_train_val, y_pred_train)
test_corr, _ = pearsonr(y_test, y_pred_test)

print(f"Training set correlation coefficient: {train_corr:.4f}")
print(f"Test set correlation coefficient: {test_corr:.4f}")

# Calculate prediction bias
train_bias = np.mean(y_pred_train - y_train_val)
test_bias = np.mean(y_pred_test - y_test)

print(f"Training set mean bias: {train_bias:.4f}")
print(f"Test set mean bias: {test_bias:.4f}")

# Training loss curve analysis
print("\n" + "="*60)
print("Training Process Analysis")
print("="*60)
if hasattr(best_model, 'loss_curve_') and best_model.loss_curve_ is not None:
    print(f"Final training loss: {best_model.loss_curve_[-1]:.6f}")
    print(f"Training iterations: {len(best_model.loss_curve_)}")
    
    # Save training process
    train_scores_df = pd.DataFrame({
        'Iteration': range(len(best_model.loss_curve_)),
        'Training Loss': best_model.loss_curve_
    })
    train_scores_df.to_excel(os.path.join(output_dir, 'MLP_Training_Process.xlsx'), index=False)
    
    # Plot training loss curve of the best model
    plt.figure(figsize=(10, 6))
    plt.plot(range(len(best_model.loss_curve_)), best_model.loss_curve_)
    plt.xlabel('Iterations')
    plt.ylabel('Training Loss')
    plt.title('Training Loss Curve of the Best MLP Model')
    plt.grid(True, alpha=0.3)
    loss_curve_path = os.path.join(output_dir, 'MLP_Best_Model_Training_Loss_Curve.png')
    plt.savefig(loss_curve_path, dpi=300, bbox_inches='tight')
    plt.show()
    print(f"Best model training loss curve saved to: {loss_curve_path}")
else:
    print("Training loss curve not available (possibly using lbfgs solver)")

print("\nMLP model training and evaluation completed!")